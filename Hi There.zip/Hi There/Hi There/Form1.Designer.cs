﻿
namespace Hi_There
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textHiThere1Port = new System.Windows.Forms.TextBox();
            this.textHiThere1IP = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textHiThere2Port = new System.Windows.Forms.TextBox();
            this.textHiThere2IP = new System.Windows.Forms.TextBox();
            this.textMessege = new System.Windows.Forms.TextBox();
            this.HiThereMesseges = new System.Windows.Forms.ListBox();
            this.Start = new System.Windows.Forms.Button();
            this.Send = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textHiThere1Port);
            this.groupBox1.Controls.Add(this.textHiThere1IP);
            this.groupBox1.Location = new System.Drawing.Point(76, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(252, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hi There 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "PORT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "IP";
            // 
            // textHiThere1Port
            // 
            this.textHiThere1Port.Location = new System.Drawing.Point(131, 56);
            this.textHiThere1Port.Name = "textHiThere1Port";
            this.textHiThere1Port.Size = new System.Drawing.Size(100, 20);
            this.textHiThere1Port.TabIndex = 1;
            // 
            // textHiThere1IP
            // 
            this.textHiThere1IP.Location = new System.Drawing.Point(131, 19);
            this.textHiThere1IP.Name = "textHiThere1IP";
            this.textHiThere1IP.Size = new System.Drawing.Size(100, 20);
            this.textHiThere1IP.TabIndex = 0;
            this.textHiThere1IP.TextChanged += new System.EventHandler(this.textHiThere1IP_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textHiThere2Port);
            this.groupBox2.Controls.Add(this.textHiThere2IP);
            this.groupBox2.Location = new System.Drawing.Point(426, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(245, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hi There 2";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(24, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "PORT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "IP";
            // 
            // textHiThere2Port
            // 
            this.textHiThere2Port.Location = new System.Drawing.Point(118, 56);
            this.textHiThere2Port.Name = "textHiThere2Port";
            this.textHiThere2Port.Size = new System.Drawing.Size(100, 20);
            this.textHiThere2Port.TabIndex = 1;
            // 
            // textHiThere2IP
            // 
            this.textHiThere2IP.Location = new System.Drawing.Point(118, 19);
            this.textHiThere2IP.Name = "textHiThere2IP";
            this.textHiThere2IP.Size = new System.Drawing.Size(100, 20);
            this.textHiThere2IP.TabIndex = 0;
            // 
            // textMessege
            // 
            this.textMessege.Location = new System.Drawing.Point(76, 392);
            this.textMessege.Name = "textMessege";
            this.textMessege.Size = new System.Drawing.Size(595, 20);
            this.textMessege.TabIndex = 2;
            // 
            // HiThereMesseges
            // 
            this.HiThereMesseges.FormattingEnabled = true;
            this.HiThereMesseges.Location = new System.Drawing.Point(76, 183);
            this.HiThereMesseges.Name = "HiThereMesseges";
            this.HiThereMesseges.Size = new System.Drawing.Size(595, 173);
            this.HiThereMesseges.TabIndex = 3;
            // 
            // Start
            // 
            this.Start.BackColor = System.Drawing.SystemColors.Info;
            this.Start.Location = new System.Drawing.Point(694, 114);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(75, 31);
            this.Start.TabIndex = 4;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = false;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // Send
            // 
            this.Send.BackColor = System.Drawing.SystemColors.Info;
            this.Send.Location = new System.Drawing.Point(694, 386);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(75, 30);
            this.Send.TabIndex = 5;
            this.Send.Text = "Send";
            this.Send.UseVisualStyleBackColor = false;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Send);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.HiThereMesseges);
            this.Controls.Add(this.textMessege);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textHiThere1Port;
        private System.Windows.Forms.TextBox textHiThere1IP;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textHiThere2Port;
        private System.Windows.Forms.TextBox textHiThere2IP;
        private System.Windows.Forms.TextBox textMessege;
        private System.Windows.Forms.ListBox HiThereMesseges;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Button Send;
    }
}

