﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.Sockets;

namespace Hi_There
{
    public partial class Form1 : Form
    {
        Socket socket;
        EndPoint endpointLocal, endpointRemote;

        public Form1()
        {
            InitializeComponent();

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

            textHiThere1IP.Text = GetLocalIP();
            textHiThere2IP.Text = GetLocalIP();
        }

        private string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return in.ToString();
                }
            }

            return "127.0.0.1";
        }


        private void MessageCallBack(IAsyncResult aResult)
        {
            try
            {
                int size = socket.EndReceiveFrom(aResult, ref endpointRemote);
                if (size > 0)
                {
                    byte[] receivedData = new byte[1464]

                        receivedData = (byte[])aResult.AsyncState

                        ASCIIEncoding eEncoding = new ASCIIEncoding();
                        string receivedMessage = eEncoding.GetString(receivedData);
                        HiThereMesseges.Items.Add("ComIT Friend:"+receivedMessage);

                }

                byte[] buffer = new byte[1500];
                socket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref endpointRemote, new AsyncCallback(MessageCallBack), buffer);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
        }
        private void textHiThere1IP_TextChanged(object sender, EventArgs e)
        {

        }

        private void Start_Click(object sender, EventArgs e)
        {

            try
            {
                System.Text.ASCIIEncoding enc = new System.ASCIIEncoding();
                byte[] msg = new byte[1500];
                msg = enc.GetBytes(textMessege.Text);

                socket.Send(msg);

                HiThereMesseges.Items.Add("You" + textMessege.Text);
                textMessege.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void Send_Click(object sender, EventArgs e)
        {
            try
            {
                endpointLocal = new IPEndPoint(IPAddress.Parse(textHiThere1IP.Text), Convert.ToInt32(textHiThere1P.Text));
                socket.Bind(endpointLocal);

                endpointRemote = new IPEndPoint(IPAdress.Parse(textHiThere2IP.Text), Convert.ToInt32(textHiThere2Port.Text));
                socket.Connect(endpointRemote);

                byte[] buffer = new byte[1500];
                socket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref endpointRemote, new AsyncCallback(MessageCallBack), buffer);

                Start.Text = "Connected";
                Start.Enabled = false;
                Send.Enabled = true;
                textMessege.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
